#!/usr/bin/python3

from which_pyqt import PYQT_VER
if PYQT_VER == 'PYQT5':
    from PyQt5.QtCore import QLineF
elif PYQT_VER == 'PYQT4':
    from PyQt4.QtCore import QLineF
else:
    raise Exception('Unsupported Version of PyQt: {}'.format(PYQT_VER))



import time



class ConvexHullSolver:
    def __init__( self, display ):
        self.points = None
        self.gui_display = display

    def compute_hull( self, unsorted_points ):
        n = len(unsorted_points)
        print( 'Computing Hull for set of {} points'.format(n) )

        t1 = time.time()
        # sort points by x-coordinate
        t2 = time.time()
        print('Time Elapsed (Sorting): {:2.2} sec'.format(t2-t1))

        t3 = time.time()
        # compute the convex hull
        t4 = time.time()


        # pass the list of lines to display
        # this is a dummy polygon of the first 3 unsorted points
        polygon = [QLineF(unsorted_points[i],unsorted_points[(i+1)%3]) for i in range(3)]
        self.gui_display.addLines( polygon, (255,0,0) )

        print('Time Elapsed (Convex Hull): {:2.2} sec'.format(t4-t3))
        self.gui_display.displayStatusText('Time Elapsed (Convex Hull): {:2.2} sec'.format(t4-t3))

        self.gui_display.update()

        #return final_hull

