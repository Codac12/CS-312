#!/usr/bin/python3

from which_pyqt import PYQT_VER
if PYQT_VER == 'PYQT5':
    from PyQt5.QtCore import QLineF, QPointF
elif PYQT_VER == 'PYQT4':
    from PyQt4.QtCore import QLineF, QPointF
else:
    raise Exception('Unsupported Version of PyQt: {}'.format(PYQT_VER))


from TSPClasses import *
from heapq import *

class TSPSolver:
    def __init__( self, gui_view ):
        self._scenario = None

    def setupWithScenario( self, scenario ):
        self._scenario = scenario


    ''' <summary>
        This is the entry point for the default solver
        which just finds a valid random tour
        </summary>
        <returns>results array for GUI that contains three ints: cost of solution, time spent to find solution, number of solutions found during search (
not counting initial BSSF estimate)</returns> '''
    def defaultRandomTour( self, start_time ):
        results = {}

        start_time = time.time()

        cities = self._scenario.getCities()
        ncities = len(cities)
        foundTour = False
        count = 0
        while not foundTour:
            # create a random permutation
            perm = np.random.permutation( ncities )

            for i in range( ncities ):
                swap = i
                while swap == i:
                    swap = np.random.randint(ncities)
                temp = perm[i]
                perm[i] = perm[swap]
                perm[swap] = temp

            route = []

            # Now build the route using the random permutation
            for i in range( ncities ):
                route.append( cities[ perm[i] ] )

            bssf = TSPSolution(route)
            #bssf_cost = bssf.cost()
            #count++;
            count += 1

            #if costOfBssf() < float('inf'):
            if bssf.costOfRoute() < float('inf'):
                # Found a valid route
                foundTour = True
        #} while (costOfBssf() == double.PositiveInfinity);                // until a valid route is found
        #timer.Stop();

        results['cost'] = bssf.costOfRoute() #costOfBssf().ToString();                          // load results array
        results['time'] = time.time() - start_time
        results['count'] = count
        results['soln'] = bssf

        return results

    def greedy( self, start_time ):

        results = {}
        start_time = time.time()
        queueMax = 0
        count = 1
        route = [self._scenario._cities[0]]
        visitedCities = [0]
        scenario = self._scenario
        bssf = None

        matrix = np.full([len(scenario._cities), len(scenario._cities)], math.inf)
        for city1 in range(len(scenario._cities)):
            for city2 in range(len(scenario._cities)):
                cost = scenario._cities[city1].costTo(scenario._cities[city2])
                if (cost != 0):
                    matrix[city1, city2] = cost

        curFromCity = 0
        for city1 in range(len(scenario._cities)):
            rowMin = math.inf
            rowMinIndex = 0
            for city2 in range(len(scenario._cities)):
                if(matrix[curFromCity, city2] < rowMin and city2 not in visitedCities):
                    rowMin = matrix[curFromCity, city2]

                    rowMinIndex = city2

            if(len(visitedCities) < len(scenario._cities)):
                curFromCity = rowMinIndex
                visitedCities.append(rowMinIndex)
                route.append(scenario._cities[rowMinIndex])

        # print(route)
        # print(visitedCities)

        bssf = TSPSolution(route)

        results['cost'] = bssf.cost
        results['time'] = time.time() - start_time
        results['count'] = count
        results['soln'] = bssf
        return results

    def branchAndBound( self, bssf, start_time ):

        results = {}
        start_time = time.time()
        queueMax = 0
        count = 1
        cnt = 0
        prunedCnt = 0

        queue = []
        curState = LowerBoundState()
        curState.initStarting(self._scenario)
        heappush(queue, (curState.weight, cnt, curState))
        # print(curState.matrix[1,0])
        while(queue):
            if (time.time() - start_time) > 60:
                prunedCnt += len(queue)
                break
            if(len(queue) > queueMax):
                queueMax = len(queue)

            popped = heappop(queue)
            curState = popped[2]
            if (curState.lowerBound > bssf.cost):
                prunedCnt += 1
                continue

            for toCity in range(curState.matrix.shape[0]):

                if(curState.matrix[curState.cityId,toCity] != math.inf and not next((x for x in curState.route if x._id == toCity), None)):
                    subState = LowerBoundState()
                    subState.initNext(curState, toCity, self._scenario._cities[toCity])

                    # subState.toString()

                    if(len(subState.route) == subState.matrix.shape[0]):
                        tempBssf = TSPSolution(subState.route)
                        tempBssf.setPath(subState.path)

                        if(tempBssf.cost < bssf.cost):
                            bssf = tempBssf
                            count += 1

                    if(subState.lowerBound < bssf.cost):
                        weight = subState.weight
                        cnt += 1
                        heappush(queue, (weight, cnt, subState))
                    else:
                        prunedCnt += 1

        results['cities'] = len(self._scenario._cities)
        results['cost'] = bssf.costOfRoute()
        results['time'] = time.time() - start_time
        results['count'] = count
        results['queueMax'] = queueMax
        results['prunedCnt'] = prunedCnt
        results['path'] = bssf.path
        results['soln'] = bssf
        return results

    def fancy( self, start_time ):
        pass



