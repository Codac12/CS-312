#!/usr/bin/python3

from which_pyqt import PYQT_VER
if PYQT_VER == 'PYQT5':
    from PyQt5.QtCore import QLineF, QPointF
elif PYQT_VER == 'PYQT4':
    from PyQt4.QtCore import QLineF, QPointF
else:
    raise Exception('Unsupported Version of PyQt: {}'.format(PYQT_VER))




import time
import numpy as np
from TSPClasses import *
from heapq import *



class TSPSolver:
    def __init__( self, gui_view ):
        self._scenario = None

    def setupWithScenario( self, scenario ):
        self._scenario = scenario


    ''' <summary>
        This is the entry point for the default solver
        which just finds a valid random tour
        </summary>
        <returns>results array for GUI that contains three ints: cost of solution, time spent to find solution, number of solutions found during search (
not counting initial BSSF estimate)</returns> '''
    def defaultRandomTour( self, start_time, time_allowance=60.0 ):

        results = {}


        start_time = time.time()

        cities = self._scenario.getCities()
        ncities = len(cities)
        foundTour = False
        count = 0
        while not foundTour:
            # create a random permutation
            perm = np.random.permutation( ncities )
            route = []

            # Now build the route using the random permutation
            for i in range( ncities ):
                route.append( cities[ perm[i] ] )

            bssf = TSPSolution(route)
            count += 1

            if bssf.costOfRoute() < np.inf:
                # Found a valid route
                foundTour = True

        results['cost'] = bssf.cost
        results['time'] = time.time() - start_time
        results['count'] = count
        results['soln'] = bssf

       # return results;
        return results


    # O(n^2)
    def greedy( self, start_time, time_allowance=60.0 ):

        results = {}
        start_time = time.time()
        count = 1
        route = [self._scenario._cities[0]]
        visitedCities = [0]
        scenario = self._scenario

        # O(n^2) to make the matrix
        matrix = np.full([len(scenario._cities), len(scenario._cities)], math.inf)
        for city1 in range(len(scenario._cities)):
            for city2 in range(len(scenario._cities)):
                cost = scenario._cities[city1].costTo(scenario._cities[city2])
                if (cost != 0):
                    matrix[city1, city2] = cost

        # O(n^2) to check all the cities for every city
        curFromCity = 0
        for city1 in range(len(scenario._cities)):
            rowMin = math.inf
            rowMinIndex = 0
            for city2 in range(len(scenario._cities)):
                if(matrix[curFromCity, city2] < rowMin and city2 not in visitedCities):
                    rowMin = matrix[curFromCity, city2]
                    rowMinIndex = city2

            if(len(visitedCities) < len(scenario._cities)):
                curFromCity = rowMinIndex
                visitedCities.append(rowMinIndex)
                route.append(scenario._cities[rowMinIndex])

        bssf = TSPSolution(route)

        results['cost'] = bssf.cost
        results['time'] = time.time() - start_time
        results['count'] = count
        results['soln'] = bssf
        return results

    # O(n^2 + (n-1)!*(log(n) + n^3 + n^2)) = O(n^3*(n-1)!)
    def branchAndBound( self, start_time, time_allowance=60.0 ):

        # O(n^2) for greedy
        bssf = self.defaultRandomTour(start_time, time_allowance)
        bssf = bssf['soln']

        results = {}
        start_time = time.time()
        queueMax = 0
        count = 1
        prunedCnt = 0
        states = 0
        queue = []

        # O(n^2)
        curState = LowerBoundState()
        curState.initStarting(self._scenario)

        #O(1)
        heappush(queue, (curState.weight, curState))
        states += 1

        # Worst Case is O((n-1)!)
        while (queue):
            if (time.time() - start_time) > time_allowance:
                prunedCnt += len(queue)
                break
            if (len(queue) > queueMax):
                queueMax = len(queue)

            # O(log(n))
            popped = heappop(queue)
            curState = popped[1]

            if (curState.lowerBound > bssf.cost):
                prunedCnt += 1
                continue

            # Repeat n times
            for toCity in range(curState.matrix.shape[0]):
                if (time.time() - start_time) > time_allowance:
                    prunedCnt += len(queue)
                    break
                if (curState.matrix[curState.cityId, toCity] != math.inf):
                    # O(n^2) - become O(n^3) inside for loop
                    subState = LowerBoundState()
                    subState.initNext(curState, toCity, self._scenario._cities[toCity])
                    states += 1

                    if (subState.lowerBound < bssf.cost):
                        if (len(subState.path) == subState.matrix.shape[0]):
                            route = []
                            # O(n) - Only runs when new complete solution is found. Becomes O(n^2) in loop
                            for i in range(subState.matrix.shape[0]):
                                route.append(self._scenario.getCities()[subState.route[i]])

                            bssf = TSPSolution(route)
                            bssf.setPath(subState.path)
                            count += 1
                        else:
                            # O(log(n))
                            heappush(queue, (subState.weight, subState))
                    else:
                            prunedCnt += 1

        results['cities'] = len(self._scenario._cities)
        results['cost'] = bssf.cost
        results['time'] = time.time() - start_time
        results['count'] = count
        results['queueMax'] = queueMax
        results['prunedCnt'] = prunedCnt
        results['path'] = bssf.path
        results['soln'] = bssf
        results['states'] = states
        return results


    def fancy( self, start_time, time_allowance=60.0 ):
        pass


