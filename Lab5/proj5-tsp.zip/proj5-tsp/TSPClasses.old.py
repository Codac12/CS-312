#!/usr/bin/python3


import math
import random
import time
import numpy as np
from copy import copy, deepcopy


class TSPSolution:
    def __init__( self, listOfCities):
        self.route = listOfCities
        self.cost = self.costOfRoute()

    def setPath(self, path):
        self.path = path

    def costOfRoute( self ):
        cost = 0
        last = self.route[0]
        for city in self.route[1:]:
            cost += last.costTo(city)
            last = city
        cost += self.route[-1].costTo( self.route[0] )
        return cost

    def enumerateEdges( self ):
        elist = []
        c1 = self.route[0]
        for c2 in self.route[1:]:
            dist = c1.costTo( c2 )
            elist.append( (c1, c2, int(math.ceil(dist))) )
            c1 = c2
        dist = self.route[-1].costTo( self.route[0] )
        elist.append( (self.route[-1], self.route[0], int(math.ceil(dist))) )
        return elist


def nameForInt( num ):
    if num == 0:
        return ''
    elif num <= 26:
        return chr( ord('A')+num-1 )
    else:
        return nameForInt((num-1) // 26 ) + nameForInt((num-1)%26+1)

class Scenario:
    def __init__( self, city_locations, difficulty ):
        self._difficulty = difficulty

        if difficulty == "Normal" or difficulty == "Hard":
            self._cities = [City( pt.x(), pt.y(), \
                                  random.uniform(0.0,1.0) \
                                ) for pt in city_locations]
        else:
            self._cities = [City( pt.x(), pt.y() ) for pt in city_locations]


        num = 0
        for city in self._cities:
            if difficulty == "Hard":
                city.setScenario(self)
            num += 1
            city.setName( nameForInt( num ) )
            city.setId( num )

            # TODO Need to remove edges
        #Scenario.current = self

    def getCities( self ):
        return self._cities


class City:
    def __init__( self, x, y, elevation=0.0 ):
        self._x = x
        self._y = y
        self._elevation = elevation
        self._scenario  = None
        self._name  = None
        self.id = 0

    def setName( self, name ):
        self._name = name

    def setId( self, num ):
        self._id = num - 1

    def setScenario( self, scenario ):
        self._scenario = scenariox

    ''' <summary>
        How much does it cost to get from this city to the destination?
        Note that this is an asymmetric cost function.
         
        In advanced mode, it returns infinity when there is no connection.
        </summary> '''
    MAP_SCALE = 1000.0

    def costTo( self, other_city ):

        assert( type(other_city) == City )

        # Euclidean Distance
        cost = math.sqrt( (other_city._x - self._x)**2 +
                          (other_city._y - self._y)**2 )

        # For Medium and Hard modes, add in an a symmetric cost (in easy mode it is zero).
        cost += (other_city._elevation - self._elevation)
        if cost < 0.0:
            cost = 0.0
        #cost *= SCALE_FACTOR

        # In hard mode, remove edges; this slows down the calculation...
        # TODO
        if self._scenario:
            pass

        return int(math.ceil(cost * self.MAP_SCALE))


class LowerBoundState:

    def __init__(self):
        self.route = list()
        self.path = list()
        pass

    def initStarting(self, scenario):
        self.cityId = 0
        self.cityName = scenario._cities[0]._name
        self.route.append(scenario._cities[0])
        self.path.append(self.cityName)
        matrix = self.makeMatrix(scenario)
        # print(matrix)
        matrix = self.reduceMatrix(matrix, -1)
        self.matrix = matrix[0]
        self.lowerBound = self.computeLowerBound(0, 0, matrix[1])
        self.weight = self.computeWeight()

    def initNext(self, prevLowerBoundState, curCityId, curCity):
        self.cityId = curCityId
        self.cityName = curCity._name
        self.route = deepcopy(prevLowerBoundState.route)
        self.route.append(curCity)
        self.path = deepcopy(prevLowerBoundState.path)
        self.path.append(self.cityName)
        prevMatrix = deepcopy(prevLowerBoundState.matrix)
        matrix = self.reduceMatrix(prevMatrix, prevLowerBoundState.cityId)
        self.matrix = matrix[0]
        self.lowerBound = self.computeLowerBound(prevLowerBoundState.lowerBound, prevLowerBoundState.matrix[prevLowerBoundState.cityId][self.cityId],  matrix[1])
        self.weight = self.computeWeight()
        pass

    def makeMatrix(self, scenario):
        matrix = np.full([len(scenario._cities), len(scenario._cities)], math.inf)
        for city1 in range(len(scenario._cities)):
            for city2 in range(len(scenario._cities)):
                cost = scenario._cities[city1].costTo(scenario._cities[city2])
                if(cost != 0):
                    matrix[city1, city2] = cost
        # print(matrix)

        return matrix

    def reduceMatrix(self, matrix, prevCityId):
        if(prevCityId != -1):
            matrix[:, self.cityId] = math.inf
            matrix[prevCityId, :] = math.inf
            matrix[self.cityId, prevCityId] = math.inf

        reduction = 0

        for row in range(matrix.shape[0]):
            mini = min(matrix[row,:])
            if(mini != math.inf):
                reduction += mini
                matrix[row,:] -= mini
        for col in range(matrix.shape[1]):
            mini = min(matrix[:,col])
            if (mini != math.inf):
                reduction += mini
                matrix[:,col] -= mini
        return (matrix, reduction)

    def computeLowerBound(self, prevLB, prevCost, thisLower):
        return prevLB + prevCost + thisLower

    def computeWeight(self):
        n = self.matrix.shape[0]
        r = len(self.route)
        return (1 + ((n-r)/n)) * self.lowerBound
        # return self.lowerBound

    def toString(self):
        print(" cityId ", self.cityId)
        print("lowerBound ", self.lowerBound)
        print("route = ", self.route)
        print("weight = ", self.weight)
        print("matrix ")
        print(self.matrix)